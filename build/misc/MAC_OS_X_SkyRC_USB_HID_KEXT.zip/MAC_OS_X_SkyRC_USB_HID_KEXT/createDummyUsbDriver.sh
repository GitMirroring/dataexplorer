#!/bin/bash
# ***** Info about kernel extension to make SkyRC USB-HID adapter usable with MAC OS X ** 30 Nov 2025 WB *****
echo The kernel extension does not contain any code, it only prevent system to allocate USB HID and enable permission for user context.
echo After iCharger kernel extension installed please reboot the system before connecting iCharger with USB-HID again.
echo MAC OS X >= 10.13 High Sierra kernel extensions might be blocked
echo To enable kext on MacOS Sonoma and newer check https://github.com/chris1111/Kext-Droplet-macOS.
